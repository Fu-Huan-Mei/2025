import TiptapListItem from '@tiptap/extension-list-item';

export default TiptapListItem;
